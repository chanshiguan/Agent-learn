# 冻结题集，用真实模型和人工复核

本单元预计 **40—60 分钟**。本章总用时见课程地图；首次安装、模型下载和等待他人审核另计。

## 不只测两道熟悉的问题

教学题集只有 6 道，用来学方法，不足以代表公司读者。候选发布前扩成明确覆盖表：有据问答、资料不足、多种合理解读、跨作品、受限阅读、启发提示、工具拒绝、重复批准、身份隔离。每类至少设计正例和反例，再按公司场景增加规模。

纯问答题放进 eval JSON；进度、教学和审批属于多步场景，要写操作步骤与预期状态，不能硬塞进只会单轮问答的 evaluate 命令。

```bash
# 在已冻结的问答题集上取得真实结果；选用自己已验证的检索方案，不临时叠加新功能。
python -m companion evaluate --cases eval/holdout.json --method keyword --generate --output release-quality-run1.json
# 另存一次独立重复运行，观察波动；不会替你填写人工评分。
python -m companion evaluate --cases eval/holdout.json --method keyword --generate --output release-quality-run2.json
```

逐题评阅后，对每份报告运行 grade。若选择 hybrid，明确改 method 并保证索引一致。两次只是教学中的波动观察，正式抽样次数与题量要按风险和成本决定。

## 处理分歧

两位评阅者对文学解释意见不同时，先分清事实错误、证据不足和合理多解。记录分歧理由，必要时请内容负责人裁定。不能只让模型给另一个模型打分，然后把分数当最终认可。

把失败列入问题清单：严重程度、复现条件、负责人、修复版本、复测结果。保留题一旦参与修复，下一轮另备未见题。第 27 章用这些材料决定候选版本是否可发布。

## 本单元完成条件

先遮住答案，回答下面的问题，再核对自己的运行记录。

1. 一次全对能证明稳定吗？
2. 多观点问题怎样评分？

<details class="answer-key"><summary>查看参考答案与通过标准</summary>

**一次全对能证明稳定吗？**

不能。模型有波动，题集也有限，需要重复、分层覆盖与明确适用范围。

**多观点问题怎样评分？**

看证据、推理和是否承认解释空间，不以是否复述唯一标准句作为唯一条件。

**通过证据：**扩展覆盖表、两次真实问答评阅、至少一个多步场景记录和未关闭问题清单。

</details>

## 下次开始前

隔一天，先不看命令，解释本单元解决了什么问题，以及哪种情况仍会失败。再用你自己的一个阅读问题重跑关键步骤。若卡住，带上单元名称、预期结果和去掉凭据的错误信息继续讨论。

## 资料依据与选读

主线概念依据 [awesome-agentic-ai-zh 对应章节](https://github.com/WenyuChiou/awesome-agentic-ai-zh/blob/main/stages/07-multi-agent-production.zh-Hans.md) 和 [Hello-Agents 对应章节](https://github.com/datawhalechina/hello-agents/tree/main/docs/chapter12)。名著例子、练习顺序和本页程序是本课程的场景化编排，不是上游仓库的逐字转载。下方拓展可随时跳过。
